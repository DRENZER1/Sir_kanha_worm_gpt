import { Router } from "express";
import { db, otpRequestsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { SendOtpBody, VerifyOtpBody } from "@workspace/api-zod";
import { randomUUID } from "crypto";

const router = Router();

function generateOtp(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

function isTestMode(): boolean {
  return !process.env.FAST2SMS_API_KEY;
}

async function sendSmsFast2Sms(phone: string, otp: string): Promise<void> {
  const apiKey = process.env.FAST2SMS_API_KEY!;
  const url = "https://www.fast2sms.com/dev/bulkV2";
  const payload = {
    route: "v3",
    sender_id: "TXTIND",
    message: `Your OTP is ${otp}. Valid for 10 minutes. Do not share with anyone.`,
    language: "english",
    flash: 0,
    numbers: phone,
  };

  const response = await fetch(url, {
    method: "POST",
    headers: {
      authorization: apiKey,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(payload),
  });

  const data = (await response.json()) as { return: boolean; message?: string[] };
  if (!data.return) {
    throw new Error(data.message?.join(", ") ?? "SMS sending failed");
  }
}

// POST /api/otp/send
router.post("/otp/send", async (req, res) => {
  const parsed = SendOtpBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request: phone is required" });
    return;
  }

  const { phone } = parsed.data;

  if (!/^\d{10}$/.test(phone)) {
    res.status(400).json({ error: "Phone must be a 10-digit number (no country code)" });
    return;
  }

  const otp = generateOtp();
  const id = randomUUID();
  const expiresAt = new Date(Date.now() + 10 * 60 * 1000);

  if (isTestMode()) {
    // Test mode: skip SMS, return OTP directly
    await db.insert(otpRequestsTable).values({
      id,
      phone,
      otp,
      status: "test",
      verified: false,
      expiresAt,
    });

    req.log.info({ id, phone }, "OTP generated in test mode");
    res.json({
      success: true,
      message: `TEST MODE — no SMS sent. Your OTP is shown below.`,
      requestId: id,
      testMode: true,
      testOtp: otp,
    });
    return;
  }

  try {
    await sendSmsFast2Sms(phone, otp);

    await db.insert(otpRequestsTable).values({
      id,
      phone,
      otp,
      status: "sent",
      verified: false,
      expiresAt,
    });

    req.log.info({ id, phone }, "OTP sent via SMS");
    res.json({
      success: true,
      message: `OTP sent to +91 ${phone}`,
      requestId: id,
      testMode: false,
      testOtp: null,
    });
  } catch (err) {
    req.log.error({ err }, "Failed to send OTP");

    await db.insert(otpRequestsTable).values({
      id,
      phone,
      otp,
      status: "failed",
      verified: false,
      expiresAt,
    }).catch(() => {});

    res.status(500).json({ error: (err as Error).message ?? "Failed to send OTP" });
  }
});

// POST /api/otp/verify
router.post("/otp/verify", async (req, res) => {
  const parsed = VerifyOtpBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "requestId and otp are required" });
    return;
  }

  const { requestId, otp } = parsed.data;

  const [record] = await db
    .select()
    .from(otpRequestsTable)
    .where(eq(otpRequestsTable.id, requestId))
    .limit(1);

  if (!record) {
    res.status(400).json({ error: "Invalid request ID" });
    return;
  }

  if (record.verified) {
    res.json({ success: false, message: "OTP already used" });
    return;
  }

  if (new Date() > record.expiresAt) {
    res.json({ success: false, message: "OTP has expired (10 min limit)" });
    return;
  }

  if (record.otp !== otp) {
    res.json({ success: false, message: "Incorrect OTP. Try again." });
    return;
  }

  await db
    .update(otpRequestsTable)
    .set({ verified: true, status: "verified" })
    .where(eq(otpRequestsTable.id, requestId));

  req.log.info({ requestId }, "OTP verified");
  res.json({ success: true, message: "OTP verified successfully!" });
});

// GET /api/otp/status
router.get("/otp/status", async (_req, res) => {
  const rows = await db
    .select({
      id: otpRequestsTable.id,
      phone: otpRequestsTable.phone,
      status: otpRequestsTable.status,
      createdAt: otpRequestsTable.createdAt,
    })
    .from(otpRequestsTable)
    .orderBy(otpRequestsTable.createdAt)
    .limit(20);

  res.json(
    rows.map((r) => ({
      ...r,
      createdAt: r.createdAt.toISOString(),
    }))
  );
});

export default router;
