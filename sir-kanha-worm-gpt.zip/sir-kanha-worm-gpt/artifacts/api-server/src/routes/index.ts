import { Router, type IRouter } from "express";
import healthRouter from "./health";
import otpRouter from "./otp";
import chatRouter from "./chat";

const router: IRouter = Router();

router.use(healthRouter);
router.use(otpRouter);
router.use(chatRouter);

export default router;
