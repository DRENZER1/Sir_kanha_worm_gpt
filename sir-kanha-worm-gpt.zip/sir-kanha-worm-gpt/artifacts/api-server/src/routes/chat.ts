import { Router } from "express";
import { getAuth } from "@clerk/express";
import crypto from "crypto";
import https from "https";
import http from "http";
import { db } from "@workspace/db";
import { chatMessagesTable, userCreditsTable } from "@workspace/db";
import { eq, and, desc } from "drizzle-orm";

const router = Router();

const FREE_CREDITS_PER_DAY = 2;
const QUESTION_COOLDOWN_SECONDS = 40;

const CHAT_API_URL = "https://chat.hackaigc.com/api/chat";
const CHAT_SECRET = "hackagic20251231";
const CHAT_FP_SECRET = "hackagic251122";
const CHAT_MODEL = "uncensored";

function sha256(text: string): string {
  return crypto.createHash("sha256").update(text).digest("hex");
}

function makeGuestUid(userId: string): string {
  const dt = `web_${userId}`;
  const t = Math.floor(dt.length / 2);
  const raw = dt.slice(t) + CHAT_FP_SECRET + dt.slice(0, t);
  return "guest_" + sha256(raw).slice(0, 32);
}

function makeRequestToken(userId: string, timestamp: number): string {
  const raw = `${CHAT_SECRET}:${userId}:${timestamp}`;
  return sha256(raw).slice(0, 32);
}

function aiChat(
  guestUid: string,
  messages: Array<{ role: string; content: string }>,
): Promise<string> {
  return new Promise((resolve, reject) => {
    const timestamp = Date.now();
    const token = makeRequestToken(guestUid, timestamp);

    const payload = JSON.stringify({
      model: CHAT_MODEL,
      messages,
      stream: false,
      user_id: guestUid,
      user_level: "free",
      deviceId: guestUid,
      enableWebSearch: false,
      images: [],
      prompt: "",
      temperature: 0.7,
      usedVoiceInput: false,
    });

    const urlObj = new URL(CHAT_API_URL);
    const options = {
      hostname: urlObj.hostname,
      path: urlObj.pathname,
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Content-Length": Buffer.byteLength(payload),
        "User-Agent": "Mozilla/5.0 (Linux; Android 10)",
        Origin: "https://chat.hackaigc.com",
        Referer: "https://chat.hackaigc.com/",
        "X-Request-Timestamp": String(timestamp),
        "X-Request-Token": token,
        Authorization: `Bearer anonymous_${guestUid}`,
      },
    };

    const lib = urlObj.protocol === "https:" ? https : http;
    const req = lib.request(options, (res) => {
      let data = "";
      res.on("data", (chunk) => (data += chunk));
      res.on("end", () => {
        if (res.statusCode && res.statusCode >= 400) {
          reject(new Error(`API error: ${res.statusCode}`));
        } else {
          resolve(data.trim() || "No response.");
        }
      });
    });

    req.on("error", reject);
    req.setTimeout(60000, () => {
      req.destroy(new Error("Request timeout"));
    });
    req.write(payload);
    req.end();
  });
}

function requireAuth(req: any, res: any, next: any) {
  const auth = getAuth(req);
  const userId = auth?.userId;
  if (!userId) {
    return res.status(401).json({ error: "Unauthorized" });
  }
  req.userId = userId;
  next();
}

router.get("/chat/status", requireAuth, async (req: any, res: any) => {
  const userId = req.userId as string;

  try {
    let credits = await db.query.userCreditsTable.findFirst({
      where: eq(userCreditsTable.userId, userId),
    });

    const now = new Date();
    const oneDayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);

    if (!credits) {
      credits = {
        userId,
        creditsUsedToday: 0,
        lastResetAt: now,
        lastMessageAt: null,
        updatedAt: now,
      };
    }

    if (credits.lastResetAt < oneDayAgo) {
      credits.creditsUsedToday = 0;
      credits.lastResetAt = now;
    }

    const creditsRemaining = Math.max(
      0,
      FREE_CREDITS_PER_DAY - credits.creditsUsedToday,
    );

    let cooldownSeconds = 0;
    if (credits.lastMessageAt) {
      const elapsed = (now.getTime() - credits.lastMessageAt.getTime()) / 1000;
      cooldownSeconds = Math.max(
        0,
        Math.ceil(QUESTION_COOLDOWN_SECONDS - elapsed),
      );
    }

    let nextCreditAt: string | null = null;
    if (creditsRemaining === 0 && credits.lastResetAt) {
      const next = new Date(
        credits.lastResetAt.getTime() + 24 * 60 * 60 * 1000,
      );
      nextCreditAt = next.toISOString();
    }

    return res.json({
      creditsUsed: credits.creditsUsedToday,
      creditsRemaining,
      maxCredits: FREE_CREDITS_PER_DAY,
      cooldownSeconds,
      nextCreditAt,
    });
  } catch (err) {
    req.log.error({ err }, "Error getting chat status");
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/chat/history", requireAuth, async (req: any, res: any) => {
  const userId = req.userId as string;

  try {
    const messages = await db
      .select()
      .from(chatMessagesTable)
      .where(eq(chatMessagesTable.userId, userId))
      .orderBy(desc(chatMessagesTable.createdAt))
      .limit(40);

    return res.json(
      messages.reverse().map((m) => ({
        role: m.role,
        content: m.content,
        createdAt: m.createdAt.toISOString(),
      })),
    );
  } catch (err) {
    req.log.error({ err }, "Error getting chat history");
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/chat/reset", requireAuth, async (req: any, res: any) => {
  const userId = req.userId as string;

  try {
    await db
      .delete(chatMessagesTable)
      .where(eq(chatMessagesTable.userId, userId));

    return res.json({ success: true });
  } catch (err) {
    req.log.error({ err }, "Error resetting chat");
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/chat/message", requireAuth, async (req: any, res: any) => {
  const userId = req.userId as string;
  const { message } = req.body;

  if (!message || typeof message !== "string" || !message.trim()) {
    return res.status(400).json({ error: "Message is required" });
  }

  try {
    const now = new Date();
    const oneDayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);

    let credits = await db.query.userCreditsTable.findFirst({
      where: eq(userCreditsTable.userId, userId),
    });

    if (!credits) {
      await db.insert(userCreditsTable).values({
        userId,
        creditsUsedToday: 0,
        lastResetAt: now,
        lastMessageAt: null,
        updatedAt: now,
      });
      credits = {
        userId,
        creditsUsedToday: 0,
        lastResetAt: now,
        lastMessageAt: null,
        updatedAt: now,
      };
    }

    if (credits.lastResetAt < oneDayAgo) {
      await db
        .update(userCreditsTable)
        .set({ creditsUsedToday: 0, lastResetAt: now, updatedAt: now })
        .where(eq(userCreditsTable.userId, userId));
      credits.creditsUsedToday = 0;
      credits.lastResetAt = now;
    }

    if (credits.creditsUsedToday >= FREE_CREDITS_PER_DAY) {
      const nextReset = new Date(
        credits.lastResetAt.getTime() + 24 * 60 * 60 * 1000,
      );
      const remaining = nextReset.getTime() - now.getTime();
      const hours = Math.floor(remaining / (1000 * 60 * 60));
      const minutes = Math.floor((remaining % (1000 * 60 * 60)) / (1000 * 60));
      return res.status(429).json({
        error: `Daily limit reached (${FREE_CREDITS_PER_DAY} free messages/day). Next credit in ${hours}h ${minutes}m.`,
      });
    }

    if (credits.lastMessageAt) {
      const elapsed = (now.getTime() - credits.lastMessageAt.getTime()) / 1000;
      if (elapsed < QUESTION_COOLDOWN_SECONDS) {
        const wait = Math.ceil(QUESTION_COOLDOWN_SECONDS - elapsed);
        return res.status(429).json({
          error: `Cooldown active. Please wait ${wait} seconds before asking another question.`,
        });
      }
    }

    const history = await db
      .select()
      .from(chatMessagesTable)
      .where(eq(chatMessagesTable.userId, userId))
      .orderBy(desc(chatMessagesTable.createdAt))
      .limit(40);

    const historyForAI = history.reverse().map((m) => ({
      role: m.role,
      content: m.content,
    }));

    historyForAI.push({ role: "user", content: message.trim() });

    const guestUid = makeGuestUid(userId);
    const reply = await aiChat(guestUid, historyForAI);

    const sessionId = userId;
    const userMsgId = crypto.randomUUID();
    const aiMsgId = crypto.randomUUID();

    await db.insert(chatMessagesTable).values([
      {
        id: userMsgId,
        userId,
        role: "user",
        content: message.trim(),
        sessionId,
        createdAt: now,
      },
      {
        id: aiMsgId,
        userId,
        role: "assistant",
        content: reply,
        sessionId,
        createdAt: new Date(now.getTime() + 1),
      },
    ]);

    const newCreditsUsed = credits.creditsUsedToday + 1;
    await db
      .update(userCreditsTable)
      .set({
        creditsUsedToday: newCreditsUsed,
        lastMessageAt: now,
        updatedAt: now,
      })
      .where(eq(userCreditsTable.userId, userId));

    return res.json({
      reply,
      creditsUsed: newCreditsUsed,
      creditsRemaining: Math.max(0, FREE_CREDITS_PER_DAY - newCreditsUsed),
    });
  } catch (err) {
    req.log.error({ err }, "Error processing chat message");
    return res.status(500).json({ error: "AI service unavailable" });
  }
});

export default router;
