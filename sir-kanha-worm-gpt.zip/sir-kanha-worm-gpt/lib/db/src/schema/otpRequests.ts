import { pgTable, text, timestamp, boolean } from "drizzle-orm/pg-core";

export const otpRequestsTable = pgTable("otp_requests", {
  id: text("id").primaryKey(),
  phone: text("phone").notNull(),
  otp: text("otp").notNull(),
  status: text("status").notNull().default("pending"),
  verified: boolean("verified").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  expiresAt: timestamp("expires_at").notNull(),
});

export type OtpRequest = typeof otpRequestsTable.$inferSelect;
export type InsertOtpRequest = typeof otpRequestsTable.$inferInsert;
