import { pgTable, text, timestamp, integer } from "drizzle-orm/pg-core";

export const chatMessagesTable = pgTable("chat_messages", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull(),
  role: text("role").notNull(),
  content: text("content").notNull(),
  sessionId: text("session_id").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const userCreditsTable = pgTable("user_credits", {
  userId: text("user_id").primaryKey(),
  creditsUsedToday: integer("credits_used_today").notNull().default(0),
  lastResetAt: timestamp("last_reset_at").notNull().defaultNow(),
  lastMessageAt: timestamp("last_message_at"),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export type ChatMessage = typeof chatMessagesTable.$inferSelect;
export type InsertChatMessage = typeof chatMessagesTable.$inferInsert;
export type UserCredits = typeof userCreditsTable.$inferSelect;
export type InsertUserCredits = typeof userCreditsTable.$inferInsert;
